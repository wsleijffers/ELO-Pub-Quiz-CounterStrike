const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '..', 'data', 'config.json');

const DEFAULTS = {
  activeEvent: null, // null = query all events; string = filter to specific event
};

/**
 * Load the admin config, merging with defaults
 */
function loadConfig() {
  const dir = path.join(__dirname, '..', 'data');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(CONFIG_PATH)) {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(DEFAULTS, null, 2));
    return { ...DEFAULTS };
  }
  return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8')) };
}

/**
 * Save the admin config
 */
function saveConfig(config) {
  const dir = path.join(__dirname, '..', 'data');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
}

/**
 * Get the currently active event filter (null = all events)
 */
function getActiveEvent() {
  return loadConfig().activeEvent;
}

/**
 * Set the active event filter
 */
function setActiveEvent(eventName) {
  const config = loadConfig();
  config.activeEvent = eventName;
  saveConfig(config);
}

/**
 * Clear the active event filter (back to all events)
 */
function clearActiveEvent() {
  const config = loadConfig();
  config.activeEvent = null;
  saveConfig(config);
}

module.exports = { getActiveEvent, setActiveEvent, clearActiveEvent };

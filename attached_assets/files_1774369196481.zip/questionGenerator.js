/**
 * Generates daily trivia questions by combining two data sources:
 * 1. EDGE Skybox API — live match stats across all events, or a specific event if set by admin
 * 2. Counter-Strike Wiki — general CS2 knowledge (weapons, maps, players, mechanics)
 *
 * Claude uses EDGE data as the primary source when available, and falls back
 * to the wiki automatically if the EDGE API returns empty data or fails.
 */

const {
  fetchPlayerStats,
  fetchTeamStats,
  fetchMatches,
  fetchClutchStats,
} = require('./edgeApi');

const { getActiveEvent } = require('./config');

// Wiki categories — used on alternating days and as EDGE fallback
const WIKI_CATEGORIES = [
  {
    category: 'weapons',
    label: '🔫 Weapons',
    prompt: 'Search the Counter-Strike Wiki at https://counterstrike.fandom.com/wiki/Counter-Strike_Wiki for detailed information about CS2 weapons — damage, fire rate, recoil, armor penetration, kill rewards, or unique mechanics. Focus on specific factual stats.',
  },
  {
    category: 'maps',
    label: '🗺️ Maps',
    prompt: 'Search the Counter-Strike Wiki at https://counterstrike.fandom.com/wiki/Counter-Strike_Wiki for information about CS2 competitive maps — their history, original release dates, designers, unique callouts, bombsite layouts, or notable map changes.',
  },
  {
    category: 'pro_players',
    label: '🎯 Pro Players',
    prompt: 'Search the Counter-Strike Wiki at https://counterstrike.fandom.com/wiki/Counter-Strike_Wiki for information about notable CS2 professional players — their nationality, career history, team history, major wins, or notable achievements.',
  },
  {
    category: 'tournaments',
    label: '🏆 Tournaments',
    prompt: 'Search the Counter-Strike Wiki at https://counterstrike.fandom.com/wiki/Counter-Strike_Wiki for information about CS2 or CS:GO major tournaments — winners, prize pools, locations, notable moments, or records set.',
  },
  {
    category: 'game_mechanics',
    label: '⚙️ Game Mechanics',
    prompt: 'Search the Counter-Strike Wiki at https://counterstrike.fandom.com/wiki/Counter-Strike_Wiki for information about CS2 game mechanics — economy system, round rules, buy phase, utility (grenades/smokes/molotovs), or gameplay systems.',
  },
];

// EDGE data types — rotated daily
const EDGE_TYPES = ['player_stats', 'team_stats', 'match_results'];

function getDayIndex() {
  return Math.floor(
    (new Date() - new Date(new Date().getFullYear(), 0, 0)) / 86400000
  );
}

/**
 * Attempt to fetch live stats from the EDGE API.
 * Reads the active event filter from config — null means all events.
 * Returns { edgeData, edgeType, eventName } or null if unavailable/empty.
 */
async function fetchEdgeData() {
  if (!process.env.EDGE_API_TOKEN) return null;

  // Read admin-configured event filter (null = all events)
  const activeEvent = getActiveEvent();
  const edgeType = EDGE_TYPES[getDayIndex() % EDGE_TYPES.length];

  try {
    let edgeData;
    if (edgeType === 'player_stats') {
      edgeData = await fetchPlayerStats(activeEvent);
    } else if (edgeType === 'team_stats') {
      edgeData = await fetchTeamStats(activeEvent);
    } else {
      const matchData = await fetchMatches(activeEvent);
      const clutchData = await fetchClutchStats(activeEvent);
      edgeData = { matches: matchData, clutch: clutchData };
    }

    // Treat empty results as unavailable
    const isEmpty =
      !edgeData ||
      (edgeData.playerStats && edgeData.playerStats.length === 0) ||
      (edgeData.teamStats && edgeData.teamStats.length === 0) ||
      (edgeData.matches && edgeData.matches.entries?.length === 0);

    if (isEmpty) {
      console.warn('EDGE API returned empty data, falling back to wiki.');
      return null;
    }

    console.log(`EDGE API data fetched — type: ${edgeType}, event filter: ${activeEvent || 'all events'}`);
    return { edgeData, edgeType, eventName: activeEvent };
  } catch (err) {
    console.warn(`EDGE API fetch failed (${err.message}), falling back to wiki.`);
    return null;
  }
}

/**
 * Build the user message for Claude based on available data sources.
 */
function buildUserMessage(edgeResult, wikiCategory) {
  if (edgeResult) {
    const { edgeData, edgeType, eventName } = edgeResult;
    const scopeLabel = eventName ? `from ${eventName}` : 'across all CS2 events';
    const edgeTypeLabel = {
      player_stats: 'player statistics',
      team_stats: 'team statistics',
      match_results: 'match results and clutch stats',
    }[edgeType];

    return `You have two data sources available to generate today's trivia question:

SOURCE 1 — Live CS2 data from the EDGE API (PRIMARY)
This is real ${edgeTypeLabel} ${scopeLabel}. Prefer this source for a question grounded in real match data.

Data:
${JSON.stringify(edgeData, null, 2)}

SOURCE 2 — Counter-Strike Wiki (SECONDARY / FALLBACK)
${wikiCategory.prompt}

Instructions:
- First try to generate a great question from SOURCE 1 (live match data)
- Only fall back to SOURCE 2 (wiki search) if the data is too sparse or doesn't yield an interesting question
- If you use SOURCE 1, set "source" to "edge" in your response
- If you use SOURCE 2, set "source" to "wiki" in your response`;
  }

  return `${wikiCategory.prompt}

Use the web_search tool to find specific factual information, then generate one trivia question from what you find.
Set "source" to "wiki" in your response.`;
}

const SYSTEM_PROMPT = `You are a CS2 esports trivia bot for a pro team fan Discord server.
Your job is to generate one fun, accurate multiple choice trivia question per day.

Rules:
- The question must be based ONLY on facts from the data provided or found via web search — never invent stats
- Provide exactly 4 answer options (A, B, C, D)
- Only one answer should be correct
- The 3 wrong options should be plausible but clearly incorrect
- Keep the question concise and fun
- Avoid questions that are too obscure or too obvious

Difficulty guidelines — assign one of these three levels:
- "easy": Broad general knowledge any CS2 player would know. Worth 5 points.
- "medium": Knowledge a dedicated fan would have (e.g. a weapon stat, a match result, a map release year). Worth 10 points.
- "hard": Deep specific knowledge only hardcore fans would know (e.g. exact damage values, clutch rates, tournament records). Worth 20 points.

Respond ONLY with a valid JSON object in this exact format, no preamble, no markdown fences:
{
  "question": "The question text here?",
  "options": {
    "A": "First option",
    "B": "Second option",
    "C": "Third option",
    "D": "Fourth option"
  },
  "correct": "A",
  "explanation": "Brief explanation of why this is correct, citing the specific stat or fact.",
  "category": "player_stats",
  "categoryLabel": "🎯 Player Stats",
  "difficulty": "medium",
  "source": "edge"
}`;

/**
 * Main entry point — generates today's trivia question from the best available source
 */
async function generateTriviaQuestion() {
  const wikiCategory = WIKI_CATEGORIES[getDayIndex() % WIKI_CATEGORIES.length];
  const edgeResult = await fetchEdgeData();
  const userMessage = buildUserMessage(edgeResult, wikiCategory);

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1500,
      system: SYSTEM_PROMPT,
      tools: [{ type: 'web_search_20250305', name: 'web_search' }],
      messages: [{ role: 'user', content: userMessage }],
    }),
  });

  const aiResponse = await response.json();

  if (!aiResponse.content || aiResponse.content.length === 0) {
    throw new Error('Empty response from Claude API');
  }

  const textBlocks = aiResponse.content.filter((block) => block.type === 'text');
  if (textBlocks.length === 0) {
    throw new Error('Claude did not return a text response');
  }

  const rawText = textBlocks[textBlocks.length - 1].text.trim();
  const cleaned = rawText.replace(/```json|```/g, '').trim();

  try {
    const question = JSON.parse(cleaned);
    console.log(`Question generated — source: ${question.source}, difficulty: ${question.difficulty}, category: ${question.category}`);
    return question;
  } catch (err) {
    console.error('Failed to parse Claude response as JSON:', rawText);
    throw new Error('Claude returned invalid JSON');
  }
}

module.exports = { generateTriviaQuestion };

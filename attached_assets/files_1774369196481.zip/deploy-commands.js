const { REST, Routes, SlashCommandBuilder } = require('discord.js');

const commands = [
  new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('🏆 Show the top 10 players in the trivia season'),

  new SlashCommandBuilder()
    .setName('stats')
    .setDescription('📊 View your personal trivia stats for this season'),

  new SlashCommandBuilder()
    .setName('season')
    .setDescription('🗓️ Show info about the current trivia season'),

  new SlashCommandBuilder()
    .setName('endseason')
    .setDescription('🏁 [Admin] End the season and award streak bonuses'),

  new SlashCommandBuilder()
    .setName('posttrivia')
    .setDescription('📢 [Admin] Manually trigger today\'s trivia question now'),

  new SlashCommandBuilder()
    .setName('setevent')
    .setDescription('📅 [Admin] Filter trivia questions to a specific CS2 event'),

  new SlashCommandBuilder()
    .setName('clearevent')
    .setDescription('🌐 [Admin] Remove event filter — trivia pulls from all events'),
].map((command) => command.toJSON());

async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

  try {
    console.log('🔄 Registering slash commands...');

    await rest.put(
      Routes.applicationGuildCommands(
        process.env.DISCORD_CLIENT_ID,
        process.env.DISCORD_GUILD_ID
      ),
      { body: commands }
    );

    console.log('✅ Slash commands registered.');
  } catch (error) {
    console.error('❌ Failed to register slash commands:', error);
  }
}

module.exports = { registerCommands };

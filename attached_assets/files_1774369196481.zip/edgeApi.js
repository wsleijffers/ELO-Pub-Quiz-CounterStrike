const EDGE_API_URL = 'https://edge.skybox.gg/api/external';

/**
 * Execute a GraphQL query against the EDGE API
 */
async function edgeQuery(query, variables = {}) {
  const response = await fetch(EDGE_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.EDGE_API_TOKEN}`,
    },
    body: JSON.stringify({ query, variables }),
  });

  const data = await response.json();

  if (data.errors) {
    console.error('EDGE API error:', data.errors);
    throw new Error(data.errors[0].message);
  }

  return data.data;
}

/**
 * Fetch a paginated list of available events from the EDGE API.
 * Used by the /setevent admin command to show admins what events exist.
 */
async function fetchAvailableEvents(page = 1) {
  const query = `
    query matchesEventSearch(
      $pagination: StrawHatPaginationPageInput!
      $orderBy: MatchesEventsOrderBy!
      $direction: OrderDirection!
    ) {
      matchesEventSearch(
        pagination: $pagination
        orderBy: $orderBy
        direction: $direction
      ) {
        entries {
          name
          slug
          lastMatchPlayedAt
        }
        totalEntries
        totalPages
      }
    }
  `;

  const variables = {
    pagination: { pageNumber: page, pageSize: 10 },
    orderBy: 'lastMatchPlayedAt',
    direction: 'desc',
  };

  const data = await edgeQuery(query, variables);
  return data.matchesEventSearch;
}

/**
 * Fetch player stats — optionally filtered by event.
 * If eventName is null, returns stats across all events.
 */
async function fetchPlayerStats(eventName = null, teamId = null) {
  const query = `
    query matchesPlayerStats(
      $teamId: ID
      $events: [String!]
      $public: Boolean
      $pagination: StrawHatPaginationPageInput!
      $orderBy: MatchesOrderBy!
      $direction: OrderDirection!
      $roundsFilters: RoundsFilters!
    ) {
      matchesPlayerStats(
        teamId: $teamId
        events: $events
        public: $public
        pagination: $pagination
        orderBy: $orderBy
        direction: $direction
        roundsFilters: $roundsFilters
      ) {
        playerStats {
          playerSteamId
          playerHandles
          mapsPlayed
          mapsWon
          roundsPlayed
          roundsWon
          kills
          deaths
          kasts
          assists
          hsKills
          damageGiven
          entryKills
          entryDeaths
          player {
            handle
            nationality
          }
        }
        totalMatches
      }
    }
  `;

  const variables = {
    teamId,
    events: eventName ? [eventName] : undefined,
    public: true,
    pagination: { pageNumber: 1, pageSize: 1 },
    orderBy: 'timestamp',
    direction: 'desc',
    roundsFilters: {},
  };

  const data = await edgeQuery(query, variables);
  return data.matchesPlayerStats;
}

/**
 * Fetch team stats — optionally filtered by event.
 * If eventName is null, returns stats across all events.
 */
async function fetchTeamStats(eventName = null, teamId = null) {
  const query = `
    query matchesTeamStats(
      $teamId: ID
      $events: [String!]
      $public: Boolean
      $pagination: StrawHatPaginationPageInput!
      $orderBy: MatchesOrderBy!
      $direction: OrderDirection!
      $roundsFilters: RoundsFilters!
    ) {
      matchesTeamStats(
        teamId: $teamId
        events: $events
        public: $public
        pagination: $pagination
        orderBy: $orderBy
        direction: $direction
        roundsFilters: $roundsFilters
      ) {
        teamStats {
          map
          mapsPlayed
          mapsWon
          mapsLost
          roundsPlayed
          roundsWon
          roundsLost
          roundsPlayedPistol
          roundsWonPistol
          kills
          deaths
          kasts
          damageGiven
        }
        totalMatches
      }
    }
  `;

  const variables = {
    teamId,
    events: eventName ? [eventName] : undefined,
    public: true,
    pagination: { pageNumber: 1, pageSize: 1 },
    orderBy: 'timestamp',
    direction: 'desc',
    roundsFilters: {},
  };

  const data = await edgeQuery(query, variables);
  return data.matchesTeamStats;
}

/**
 * Fetch match results — optionally filtered by event.
 * If eventName is null, returns matches across all events.
 */
async function fetchMatches(eventName = null, teamId = null) {
  const query = `
    query matchesSearch(
      $teamId: ID
      $events: [String!]
      $public: Boolean
      $pagination: StrawHatPaginationPageInput!
      $orderBy: MatchesOrderBy!
      $direction: OrderDirection!
    ) {
      matchesSearch(
        teamId: $teamId
        events: $events
        public: $public
        pagination: $pagination
        orderBy: $orderBy
        direction: $direction
      ) {
        entries {
          hash
          map
          teamAlphaClan
          teamBravoClan
          alphaFinalScore
          bravoFinalScore
          winner
          playedAt
          event { name }
          playerStats {
            playerSteamId
            playerHandles
            stats {
              kills
              deaths
              kasts
              damageGiven
            }
          }
        }
        totalEntries
      }
    }
  `;

  const variables = {
    teamId,
    events: eventName ? [eventName] : undefined,
    public: true,
    pagination: { pageNumber: 1, pageSize: 20 },
    orderBy: 'timestamp',
    direction: 'desc',
  };

  const data = await edgeQuery(query, variables);
  return data.matchesSearch;
}

/**
 * Fetch clutch stats — optionally filtered by event.
 * If eventName is null, returns stats across all events.
 */
async function fetchClutchStats(eventName = null, teamId = null) {
  const query = `
    query matchesPlayerClutchStats(
      $teamId: ID
      $events: [String!]
      $public: Boolean
      $pagination: StrawHatPaginationPageInput!
      $orderBy: MatchesOrderBy!
      $direction: OrderDirection!
      $roundsFilters: RoundsFilters!
    ) {
      matchesPlayerClutchStats(
        teamId: $teamId
        events: $events
        public: $public
        pagination: $pagination
        orderBy: $orderBy
        direction: $direction
        roundsFilters: $roundsFilters
      ) {
        playerClutchStats {
          playerSteamId
          playerHandles
          roundsPlayed
          clutch1v1Played
          clutch1v1Won
          clutch1v2Played
          clutch1v2Won
          clutch1v3Played
          clutch1v3Won
          clutch1v4Played
          clutch1v4Won
          clutch1v5Played
          clutch1v5Won
          player { handle }
        }
        totalMatches
      }
    }
  `;

  const variables = {
    teamId,
    events: eventName ? [eventName] : undefined,
    public: true,
    pagination: { pageNumber: 1, pageSize: 1 },
    orderBy: 'timestamp',
    direction: 'desc',
    roundsFilters: {},
  };

  const data = await edgeQuery(query, variables);
  return data.matchesPlayerClutchStats;
}

module.exports = {
  fetchAvailableEvents,
  fetchPlayerStats,
  fetchTeamStats,
  fetchMatches,
  fetchClutchStats,
};

const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { postDailyTrivia } = require('./trivia');
const { getActiveEvent, setActiveEvent, clearActiveEvent } = require('./config');
const { fetchAvailableEvents } = require('./edgeApi');
const {
  loadTriviaState,
  saveTriviaState,
  recordCorrectAnswer,
  recordWrongAnswer,
  getLeaderboard,
  getUserStats,
  applySeasonEndBonuses,
} = require('./database');

/**
 * Main interaction router
 */
async function handleInteraction(interaction) {
  if (interaction.isButton()) {
    await handleButtonInteraction(interaction);
  } else if (interaction.isChatInputCommand()) {
    await handleSlashCommand(interaction);
  } else if (interaction.isStringSelectMenu()) {
    await handleSelectMenu(interaction);
  }
}

/**
 * Handle trivia answer button presses
 */
async function handleButtonInteraction(interaction) {
  const { customId, user } = interaction;

  // Only handle trivia answer buttons
  if (!customId.startsWith('trivia_answer_')) return;

  // Parse: trivia_answer_A_2025-07-10
  const parts = customId.split('_');
  const chosenAnswer = parts[2]; // A, B, C, or D
  const date = parts[3]; // YYYY-MM-DD

  const state = loadTriviaState();
  const todayState = state[date];

  if (!todayState) {
    return interaction.reply({
      content: "⚠️ This trivia question has expired.",
      ephemeral: true,
    });
  }

  // Check if user already answered
  if (todayState.answeredUsers[user.id]) {
    const theirAnswer = todayState.answeredUsers[user.id];
    const isCorrect = theirAnswer === todayState.question.correct;
    return interaction.reply({
      content: isCorrect
        ? `✅ You already answered **${theirAnswer}** — which was correct! Nice work.`
        : `❌ You already answered **${theirAnswer}**, which was wrong. Better luck tomorrow!`,
      ephemeral: true,
    });
  }

  // Record their answer
  todayState.answeredUsers[user.id] = chosenAnswer;
  state[date] = todayState;
  saveTriviaState(state);

  const isCorrect = chosenAnswer === todayState.question.correct;
  const difficulty = todayState.question.difficulty || 'medium';

  if (isCorrect) {
    const result = recordCorrectAnswer(user.id, user.username, difficulty);

    const diffEmoji = { easy: '🟢', medium: '🟡', hard: '🔴' }[difficulty] || '🟡';

    let streakMsg = '';
    if (result.currentStreak >= 7) {
      streakMsg = `\n🔥 **${result.currentStreak}-day streak!** You're on fire!`;
    } else if (result.currentStreak >= 3) {
      streakMsg = `\n🔥 ${result.currentStreak}-day streak! Keep it going!`;
    }

    const bonusMsg =
      result.streakBonus > 0 ? ` (+${result.streakBonus} streak bonus)` : '';

    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setTitle('✅ Correct!')
          .setDescription(
            `Nice one, **${user.username}**! You earned **+${result.pointsEarned} points** ${diffEmoji} ${difficulty}${bonusMsg}.\n` +
              `🏅 Total: **${result.totalPoints} pts** · 🔥 Streak: **${result.currentStreak} day${result.currentStreak !== 1 ? 's' : ''}**` +
              streakMsg
          )
          .setColor(0x57f287)
          .setFooter({ text: 'Use /stats to see your full profile' }),
      ],
      ephemeral: true,
    });
  } else {
    const result = recordWrongAnswer(user.id, user.username);

    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setTitle('❌ Wrong answer')
          .setDescription(
            `Not quite, **${user.username}**. Your streak has been reset.\n` +
              `🏅 Total points: **${result.totalPoints} pts** · The correct answer will be revealed in 24 hours.`
          )
          .setColor(0xed4245)
          .setFooter({ text: 'Use /stats to see your full profile' }),
      ],
      ephemeral: true,
    });
  }
}

/**
 * Handle slash commands
 */
async function handleSlashCommand(interaction) {
  const { commandName } = interaction;

  if (commandName === 'leaderboard') {
    await handleLeaderboard(interaction);
  } else if (commandName === 'stats') {
    await handleStats(interaction);
  } else if (commandName === 'season') {
    await handleSeason(interaction);
  } else if (commandName === 'endseason') {
    await handleEndSeason(interaction);
  } else if (commandName === 'posttrivia') {
    await handlePostTrivia(interaction);
  } else if (commandName === 'setevent') {
    await handleSetEvent(interaction);
  } else if (commandName === 'clearevent') {
    await handleClearEvent(interaction);
  }
}

/**
 * /leaderboard — Show top 10 players
 */
async function handleLeaderboard(interaction) {
  const leaders = getLeaderboard(10);

  if (leaders.length === 0) {
    return interaction.reply({
      content: "No scores yet — answer today's trivia to get on the board!",
      ephemeral: true,
    });
  }

  const medals = ['🥇', '🥈', '🥉'];
  const rows = leaders.map((user, i) => {
    const medal = medals[i] || `**${i + 1}.**`;
    const streak =
      user.currentStreak > 0 ? ` 🔥 ${user.currentStreak}` : '';
    return `${medal} **${user.username}** — ${user.totalPoints} pts${streak}`;
  });

  const embed = new EmbedBuilder()
    .setTitle(`🏆 Season Leaderboard — ${process.env.SEASON_EVENT_NAME}`)
    .setDescription(rows.join('\n'))
    .addFields({
      name: 'Scoring',
      value: '✅ +10 pts per correct answer · 🔥 +2 pts per streak day\n🏆 Season-end bonus for top 3 longest streaks: 50 / 30 / 10 pts',
    })
    .setColor(0xe8a838)
    .setFooter({ text: 'Use /stats to see your personal stats' })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}

/**
 * /stats — Show the caller's personal stats
 */
async function handleStats(interaction) {
  const stats = getUserStats(interaction.user.id);

  if (!stats) {
    return interaction.reply({
      content: "You haven't answered any trivia questions yet. Get started today!",
      ephemeral: true,
    });
  }

  const accuracy =
    stats.totalAnswered > 0
      ? Math.round((stats.totalCorrect / stats.totalAnswered) * 100)
      : 0;

  const embed = new EmbedBuilder()
    .setTitle(`📊 ${stats.username}'s Trivia Stats`)
    .addFields(
      { name: '🏅 Total Points', value: `${stats.totalPoints}`, inline: true },
      { name: '🔥 Current Streak', value: `${stats.currentStreak} days`, inline: true },
      { name: '⚡ Longest Streak', value: `${stats.longestStreak} days`, inline: true },
      { name: '✅ Correct', value: `${stats.totalCorrect}`, inline: true },
      { name: '📝 Answered', value: `${stats.totalAnswered}`, inline: true },
      { name: '🎯 Accuracy', value: `${accuracy}%`, inline: true }
    )
    .setColor(0x5865f2)
    .setFooter({ text: `Season: ${process.env.SEASON_EVENT_NAME}` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed], ephemeral: true });
}

/**
 * /season — Show season info
 */
async function handleSeason(interaction) {
  const endDate = process.env.SEASON_END_DATE;
  const eventName = process.env.SEASON_EVENT_NAME;

  const daysLeft = endDate
    ? Math.max(
        0,
        Math.ceil((new Date(endDate) - new Date()) / (1000 * 60 * 60 * 24))
      )
    : null;

  const embed = new EmbedBuilder()
    .setTitle(`🗓️ Season Info — ${eventName}`)
    .setDescription(
      `The trivia season is tied to **${eventName}**.\nQuestions are generated from real match data from this tournament.`
    )
    .addFields(
      {
        name: '📅 Season Ends',
        value: endDate ? `${endDate} (${daysLeft} days left)` : 'TBD',
        inline: true,
      },
      {
        name: '🏆 Season Bonuses',
        value: '🥇 Longest streak: +50 pts\n🥈 2nd longest: +30 pts\n🥉 3rd longest: +10 pts',
      }
    )
    .setColor(0xe8a838)
    .setFooter({ text: 'Use /leaderboard to see current standings' });

  await interaction.reply({ embeds: [embed] });
}

/**
 * /endseason — Admin command to finalise the season and award streak bonuses
 */
async function handleEndSeason(interaction) {
  // Only server admins can end the season
  if (!interaction.memberPermissions.has('Administrator')) {
    return interaction.reply({
      content: '⛔ Only server administrators can end the season.',
      ephemeral: true,
    });
  }

  await interaction.deferReply();

  const bonusRecipients = applySeasonEndBonuses();

  if (bonusRecipients.length === 0) {
    return interaction.editReply('No players have streak data to award bonuses to.');
  }

  const medals = ['🥇', '🥈', '🥉'];
  const bonusLines = bonusRecipients.map(
    (r) =>
      `${medals[r.rank - 1]} **${r.username}** — longest streak: **${r.longestStreak} days** → **+${r.bonus} pts** (Total: ${r.finalPoints} pts)`
  );

  const leaderboard = getLeaderboard(10);
  const leaderLines = leaderboard.map((u, i) => {
    const medal = medals[i] || `**${i + 1}.**`;
    return `${medal} **${u.username}** — ${u.totalPoints} pts`;
  });

  const embed = new EmbedBuilder()
    .setTitle(`🏁 Season Over — ${process.env.SEASON_EVENT_NAME}`)
    .setDescription('The season has ended! Streak bonuses have been awarded. 🎉')
    .addFields(
      { name: '⚡ Streak Bonuses Awarded', value: bonusLines.join('\n') },
      { name: '🏆 Final Standings', value: leaderLines.join('\n') }
    )
    .setColor(0xe8a838)
    .setTimestamp();

  await interaction.editReply({ embeds: [embed] });
}

/**
 * /setevent — Admin command to filter trivia to a specific event
 * Fetches the 10 most recent events from EDGE API and shows a dropdown
 */
async function handleSetEvent(interaction) {
  if (!interaction.memberPermissions.has('Administrator')) {
    return interaction.reply({
      content: '⛔ Only server administrators can change the event filter.',
      ephemeral: true,
    });
  }

  await interaction.deferReply({ ephemeral: true });

  try {
    const result = await fetchAvailableEvents(1);
    const events = result.entries;

    if (!events || events.length === 0) {
      return interaction.editReply('⚠️ No events found in the EDGE API. Make sure your EDGE_API_TOKEN is set correctly.');
    }

    const currentEvent = getActiveEvent();

    // Build a select menu with the available events
    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('select_event')
      .setPlaceholder('Choose an event...')
      .addOptions(
        events.map((e) => ({
          label: e.name,
          description: e.lastMatchPlayedAt
            ? `Last match: ${e.lastMatchPlayedAt.split('T')[0]}`
            : 'No match date available',
          value: e.name,
          default: e.name === currentEvent,
        }))
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);

    await interaction.editReply({
      content: `**Select an event to filter trivia questions:**\nCurrently active: **${currentEvent || 'All events'}**\n\nShowing the 10 most recent events. Use \`/clearevent\` to go back to all events.`,
      components: [row],
    });
  } catch (err) {
    console.error('❌ /setevent failed:', err);
    await interaction.editReply('❌ Failed to fetch events from the EDGE API. Check that your EDGE_API_TOKEN is set in Replit Secrets.');
  }
}

/**
 * /clearevent — Admin command to remove event filter
 */
async function handleClearEvent(interaction) {
  if (!interaction.memberPermissions.has('Administrator')) {
    return interaction.reply({
      content: '⛔ Only server administrators can change the event filter.',
      ephemeral: true,
    });
  }

  clearActiveEvent();

  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setTitle('🌐 Event Filter Cleared')
        .setDescription('Trivia questions will now pull from **all CS2 events** in the EDGE API.\n\nUse `/setevent` to filter to a specific event.')
        .setColor(0x5865f2),
    ],
    ephemeral: true,
  });
}

/**
 * Handle the event selection dropdown from /setevent
 */
async function handleSelectMenu(interaction) {
  if (interaction.customId !== 'select_event') return;

  if (!interaction.memberPermissions.has('Administrator')) {
    return interaction.reply({
      content: '⛔ Only server administrators can change the event filter.',
      ephemeral: true,
    });
  }

  const selectedEvent = interaction.values[0];
  setActiveEvent(selectedEvent);

  await interaction.update({
    content: null,
    embeds: [
      new EmbedBuilder()
        .setTitle('📅 Event Filter Set')
        .setDescription(`Trivia questions will now be filtered to:\n\n**${selectedEvent}**\n\nUse \`/clearevent\` to go back to all events.`)
        .setColor(0x57f287),
    ],
    components: [],
  });
}

/**
 * /posttrivia — Admin command to manually trigger a trivia question immediately
 */
async function handlePostTrivia(interaction) {
  // Only server admins can manually trigger trivia
  if (!interaction.memberPermissions.has('Administrator')) {
    return interaction.reply({
      content: '⛔ Only server administrators can manually post trivia.',
      ephemeral: true,
    });
  }

  // Check if a question has already been posted today
  const { loadTriviaState } = require('./database');
  const today = new Date().toISOString().split('T')[0];
  const state = loadTriviaState();

  if (state[today]) {
    return interaction.reply({
      content: `⚠️ A trivia question has already been posted today (${today}). Use tomorrow's scheduled post or wait until midnight UTC.`,
      ephemeral: true,
    });
  }

  // Defer reply as question generation can take a few seconds
  await interaction.reply({
    content: '⏳ Generating today\'s trivia question, please wait...',
    ephemeral: true,
  });

  try {
    const channel = interaction.channel;
    await postDailyTrivia(channel);

    await interaction.editReply({
      content: `✅ Trivia question posted successfully to ${channel}!`,
    });
  } catch (err) {
    console.error('❌ /posttrivia failed:', err);
    await interaction.editReply({
      content: '❌ Failed to generate the trivia question. Check the bot logs for details.',
    });
  }
}

module.exports = { handleInteraction };
